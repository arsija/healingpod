<?php
echo 'Laravel Application Home';