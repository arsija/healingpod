<?php
return [
    'database' => 'example_db',
    'username' => 'root',
    'password' => 'password',
];